import React from "react";
import "./App.css";
import { Video } from "./Components/Video";
import videos from "./data";
import {PlayButton} from "./Components/PlayButton";

const App = () => (
  <div className="container" onClick={()=>console.log("App")}>
    {videos.map((e) => (
      <Video
        key={e.id}
        srcValue={e.src}
        views={e.views}
        verified={e.verified}
        channel={e.channel}
        id={e.id}
      >
<PlayButton onPlay={()=>console.log(e.channel," played")} onPause={()=>console.log(e.channel," paused")} >Play</PlayButton>
      </Video>
    ))}
  </div>
);
export default App;
