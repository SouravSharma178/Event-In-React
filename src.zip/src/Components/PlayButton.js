import React from 'react'
import "./PlayButton.css"

const PlayButton = ({onPlay,onPause,children}) => {
  let playButtonStatus = false;
  function handleClick(e){
    e.stopPropagation()
    if(playButtonStatus){
      onPause();
    } else{
      onPlay();
    }
  playButtonStatus = !playButtonStatus;
  }
  return (
    <button className="container" id="button" onClick={handleClick}>{children}
    </button>
  )
}

export {PlayButton};
